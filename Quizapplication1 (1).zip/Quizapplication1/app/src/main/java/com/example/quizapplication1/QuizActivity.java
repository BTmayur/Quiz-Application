package com.example.quizapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {

    private TextView questionTextView;
    private RadioGroup choicesRadioGroup;
    private Button submitBtn;

    private String[] questions = {
            "How many states are there in India?",
            "What is the capital of france?",
            "What is cube of 3?",
            "Who painted the Mona Lisa?",
            "What is the largest planet in our solar system?"

    };

    private String[][] choices = {
            {"28", "29", "27", "26"},
            {"Paris", "London", "Rome", "Berlin"},
            {"9", "6", "27", "35"},
            {"Leonardo da Vinci", "Pablo Picasso", "Vincent van Gogh", "Michelangelo"},
            {"Jupiter", "Saturn", "Mars", "Earth"}

    };

    private int[] correctAnswers = {1, 1, 3, 2, 3};
    private int currentQuestionIndex = 0;
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionTextView = findViewById(R.id.questionTextView);
        choicesRadioGroup = findViewById(R.id.choicesRadioGroup);
        submitBtn = findViewById(R.id.submitBtn);

        displayQuestion();

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedChoiceId = choicesRadioGroup.getCheckedRadioButtonId();

                if (selectedChoiceId != -1) {
                    RadioButton selectedChoice = findViewById(selectedChoiceId);
                    int selectedAnswer = choicesRadioGroup.indexOfChild(selectedChoice) + 1;

                    checkAnswer(selectedAnswer);

                    currentQuestionIndex++;

                    if (currentQuestionIndex < questions.length) {
                        displayQuestion();
                    } else {
                        // Quiz finished, show score
                        Toast.makeText(QuizActivity.this, "Quiz finished! Your score: " + score, Toast.LENGTH_SHORT).show();
                        // Quiz finished, show score
                        Intent intent = new Intent(QuizActivity.this, ResultsActivity.class);
                        intent.putExtra("score", score);
                        intent.putExtra("totalQuestions", questions.length);
                        startActivity(intent);
                        finish();

                    }

                } else {
                    Toast.makeText(QuizActivity.this, "Please select an answer", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void displayQuestion() {
        questionTextView.setText(questions[currentQuestionIndex]);

        for (int i = 0; i < choicesRadioGroup.getChildCount(); i++) {
            RadioButton choice = (RadioButton) choicesRadioGroup.getChildAt(i);
            choice.setText(choices[currentQuestionIndex][i]);
        }
        choicesRadioGroup.clearCheck();
    }

    private void checkAnswer(int selectedAnswer) {
        if (selectedAnswer == correctAnswers[currentQuestionIndex]) {
            score++;
        }
    }
}
